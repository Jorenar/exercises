% File: c18_cdmasim.m
function [BER, ErrorRun]=c18_cdmasim(N,SF,EbNo,NumInterferers,MPathDelay,Kfactor_dB)
rand('state', sum(100*clock)); randn('state', sum(100*clock));
NIterate = 1e3; % defaultowy rozmiar bloku
NumberOfIterations = ceil(N/NIterate);
ErrorState = 0; ErrorRun = []; RunCount = 1; % initialize
Kfactor = 10^(Kfactor_dB/10); % linear units
EbNolinear = 10^(EbNo/10); % linear units
MPathComponents = length(MPathDelay);
%
% Wyznacz amplitudę w wielodrogowych komponentach oraz przechowaj jako wektor .
% Wyznacz całkowitą moc we wszystkich komponentach.
% Wyznacz komponent LOS - Line-of-sight
%
MPathAmp(2:MPathComponents) = rand(MPathComponents - 1, 1);
ScatPower = MPathAmp*MPathAmp.';
MPathAmp(1) = sqrt(ScatPower*Kfactor); % LOS komponent.
%
% Wyznacz, który komponent ma największą energię
% Znormalizuj wektor, tak aby najsilniejszy komponent miał amplitudę jednostkową
%
[fee MaxComponent] = max(MPathAmp); MPathAmp = MPathAmp/fee;
%
% Zaprojektuj filtr IIR dla zaniku sygnału
%
FilterOrder = 4; Ripple = 0.5; BW = 0.01; % parametry filtra
[b,a] = cheby1(FilterOrder, Ripple, BW); % filtr rzędu 4-tego
%
% wyznaczenie błędu
%
if NumInterferers > (SF - 1)
    error(['NumInterferers nie może przekraczać ' , int2str(SF-1),'.'])
end
if length(MPathDelay) ~= length(MPathAmp)
    error('MPathDelay oraz MPathAmp muszą mieć tę samą długość .')
end
if min(MPathDelay) < 0
    error('PathDelay nie mogą mieć ujemnego komponentu.')
end
fee = diff(MPathDelay);
if min(fee) <= 0
    error('MPathDelay musi być monotonicznie rosnące.')
end
clear fee
%
% Koniec oznaczania błędu
%
% Generuje sekwencję rozpraszania
%
DesiredSequence = MSequence(SF + 1); % pożądany sygnał
offset = fix(length(DesiredSequence)/(NumInterferers + 1));
M = length(DesiredSequence);
for k = 1:NumInterferers
    InterfererSequence(k,:) = [DesiredSequence(M-(k-1)*offset:M) DesiredSequence(1:M-1-(k-1)*offset)];
end
%
% Początek pętli symulacji
%
zf = zeros(FilterOrder,MPathComponents);
for cnt=1:NumberOfIterations
    %
    % Generuje i rozprasza symbole dla danego użytkownika
    %
    DesiredSymbols = sign(rand(1,NIterate)-0.5);
    InterfereringSymbols = sign(rand(NumInterferers,NIterate)-0.5);
    DesiredChips = reshape(DesiredSequence.'*DesiredSymbols,1,M*NIterate);
    for k=1:NumInterferers
        InterferingChips(k,:) = reshape(InterfererSequence(k,:),1,M*NIterate);
end
% generuje szum
%
NoiseAmplitude = sqrt(SF/(2*EbNolinear));
MaxDelay = max(MPathDelay);
DesiredNoise = NoiseAmplitude*randn(1,M*NIterate+MaxDelay);
%
% Zastosuj wielodrogowość
%
MPathLinAmp = MPathAmp;
MPathComponents = length(MPathDelay);
DesiredMPathSignal =zeros(1,M*NIterate+MaxDelay);
if NumInterferers > 0
    InterferingMPathSignal = zeros(NumInterferers,M*NIterate+MaxDelay);
    for k = 1:MPathComponents
        index = 1+MPathDelay(k):NIterate*(M+MPathDelay(k));
        InterfereingMPathSignal(:,index) + MPathLinAmp(k)*InterferingChips;
    end
end
for k = 1:MPathComponents
    if k == 1, fading = ones(1,M*NIterate);
    else
        fading = randn(size(DesiredSymbols))+j*randn(size(DesiredSymbols));
        [fading zf(:,k)] = filter(b,a,fading,zf(:,k));
        fading = interp(fading,SF);
        fading = interp(fading,SF);
        fading = abs(fading/sqrt(mean(fading.*conj(fading))));
    end
    if k == MaxComponent
        fadesign = sign(fading);
    end
    faa(k,:) = MPathLinAmp(k); %*fading;
    index = 1+MPathDelay(k):NIterate*M+MPathDelay(k);
    DesiredMPathSignal(index) = DesiredMPathSignal(index) + (MPathLinAmp(k)).*DesiredChips;
end
%
% Dodaj interferencję oraz szum
%
if NumInterferers > 0
    IncomingSignal = DesiredMPathSignal+sum(InterferingMPathSignal,1)+DesiredNoise;
else
    IncomingSignal = DesiredMPathSignal+DesiredNoise;
end
%
% odbiera wchodzący sygnał
%
index = 1+MPathDelay(MaxComponent):M*NIterate+MPathDelay(MaxComponent);
IncomingChips = reshape(fadesign.*IncomingSignal(index),M,NIterate);
DespreadSymbols = DesiredSequence*IncomingChips;
DetectedSymbols = sign(DespreadSymbols);
%
% Oblicz wielkość błędu
%
ErrorVector =0.5*abs(DetectedSymbols-DesiredSymbols);
ErrorIterate(cnt) = sum(ErrorVector);
BERIterate(cnt) = ErrorIterate(cnt)/NIterate;
for k = 1:NIterate
    if (ErrorVector(k) == 0) & (ErrorState == 0)
        RunCount = RunCount + 1;
elseif (ErrorVector(k) == 0) & (ErrorState == 1)
    ErrorRun = [ErrorRun RunCount];
    RunCount = 1; ErrorState = 0;
elseif (ErrorVector(k) == 1) & (ErrorState ==0)
    ErrorRun = [ErrorRun RunCount];
    RunCount = 1; ErrorState = 1;
elseif (ErrorVector(k) == 1) & (ErrorState == 1)
    RunCount = RunCount+1;
else
    s1 = sprintf('ErrorVector(%d)=%d, ErrorState=%d! Unexpected Condition!');
    error(s1);
end
end
end
Errors = sum(ErrorIterate); BER = mean(BERIterate);
ErrorRun = [ErrorRun RunCount];
% koniec funkcji
