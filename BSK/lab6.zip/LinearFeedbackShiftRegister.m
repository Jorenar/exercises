% Plik: LinearFeedbackShiftRegiater.m
% File: LinearFeedbackShiftRegister.m
function [y,outstate]= LinearFeedbackShiftRegister(R,generator,instate,N)
if max(generator) > R
    error(['The degree of the generator polynomial, ', int2str(max(generator)),', cannot exceed R, ',int2str(R),'.']);
end
if length(instate) > R
    error(['The length of the input state vector, ', int2str(length(instate)),', cannot exceed R, ',int2str(R),'.']);
end
a = sort(generator); P = length(generator); M = length(instate)+1;
for k=1:N
    fee = instate((generator(2)));
    for q=3:P
        fee = bitxor(fee,instate(generator(q)));
end
instate = [fee instate]; y(k) = instate(1); instate(M) = [];
end
outstate = instate;
% Koniec pliku funkcji LinearFeedBackShiftRegister.m
