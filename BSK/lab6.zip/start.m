N = 100000;
EoNdB = 5;
EbNo = 10^(EoNdB/10);
KdB = 0; SF = 7; NoI = 0;
MPathDelay = [0 3 4];
%
% symulacja CDMA
%
[BER,ErrorRun] = c18_cdmasim(N,SF,EbNo,NoI,MPathDelay,KdB);
% wymagany wektor z czasem symulacji
lenER = length(ErrorRun);
row2 = zeros(1,lenER);
row2(2:2:lenER)=1;
runcode1(1,:) = ErrorRun;
runcode1(2,:)=row2;
%
% - generuj łańcuch semi_Markowa
%
[A_matrix, pi_est] = c15_semiMarkov(runcode1,50,[2 1]);
save cdmadata1 N BER ErrorRun A_matrix runcode1
% koniec pliku
