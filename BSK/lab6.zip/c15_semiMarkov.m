% Plik: c15_semiMarkov.m
function [A_matrix, pi_est] = c15_semiMarkov(runlength,cycles, partition)
% runlength = runlength code
% cycles = number of iterations
% partition = 1 by 2 vector = [good states, bad states]
%
[symbols len_symbols] = size(runlength); % podaje rozmiar wektora runlength
m= runlength(1,:); % - pierwszy otrzymany bit jest wolny od błędu
u = runlength(2,:); % dowolna liczba elementów
C = len_symbols; % całkowita długość wektora runlength
%
A = cell(length(partition)); % tablica 2x2 - tylko dwa symbole
pye = rand(1,sum(partition)); % inicjalizacja początkowego wektora stanu
pye = pye(1,:); % normalizacja
pi_u1 = pye(1:partition(1));
%
% inicjalizacja macierzy A
%
A = cell(partition); % alokacja pamięci dla macierzy A
A00 = diag(1 - abs(randn(partition(1),1)/1000)); % inicjalizacja A00
A10 = rand(partition(2), partition(1)); % inicjalizacja A10
A01 = rand(partition(1),partition(2)); % inicjalizacja A01
A11 = diag(1 - abs(randn(partition(2),1)/1000)); % inicjalizacja A11
A{1,1} = A00; A{1,2} = A01; A{2,1} = A10; A{2,2} = A11;
A_matrix = [A{1,1} A{1,2}; A{2,1} A{2,2}]; % macierz w postaci komórek
%
for i = 1: sum(partition)
    A_matrix(i,:) = A_matrix(i,:)/sum(A_matrix(i,:)); % normalizacja macierzy A
end
A_matrix;
%
A{1} = A_matrix(1:partition(1),1: partition(1));
A{2} = A_matrix(partition(1)+1:partition(1)+partition(2),1:partition(1));
A{3} = A_matrix(1:partition(1),partition(1)+1:partition(1)+partition(2));
A{4} = A_matrix(partition(1)+1:partition(1)+partition(2));
for iteration = 1:cycles
    %
    % generacja alpha
    %
    alpha{1} = pi_u1*(A{u(1)+1, u(1)+1}.^(m(1)-1)); scale(1)=sum(alpha{1});
    alpha{1} = alpha{1}/scale(1); % normalizacja
    for c=2:C
        alpha{c} = alpha{c-1}*A{u(c-1)+1,u(c)+1}*A{u(c)+1,u(c)+1}^(m(c)-1);
        scale(c) = sum(alpha{c}); % skalowanie
        alpha{c} = alpha{c}/scale(c); % normalizacja alpha
end
%
% generacja beta
%
beta{c} = ones(partition(u(C)+1),1)/scale(C); % ostatni element beta
for (c=C-1:-1:1)
    beta{c}=A{u(c)+1,u(c+1)+1}*(A{u(c+1)+1,u(c+1)+1}^(m(c+1)-1))*(beta{c+1}/scale);
end;
%
% generacja gamma
%
Gamma{1} = alpha{1}.*beta{1}';
Gamma{2} = alpha{2}.*beta{2}';
%
sum_Tii_00s = diag(zeros(partition(1),1));
sum_Tii_11s = diag(zeros(partition(2),1));
sum_Tij_01s = zeros(partition(1),partition(2));
sum_Tij_10s = zeros(partition(2),partition(1));
%
% re estymacja macierzy A00
%
for c=1:2:C-1
    if (c == 1)
        Tii_00s = diag((m(1)-1)*(pi_u1))'.*(diag(A{u(1)+1,u(1)+1}).^(m(1)-1).*beta{1});
else
    Tii_00s = diag((m(c)-1)*((alpha{c-1}*A{u(c-1)+1, u(c)+1})'.*(diag(A{u(c)+1,u(c)+1}^(m(c)-1))))*beta{c});
end
sum_Tii_00s = sum_Tii_00s + Tii_00s; % suma elementów A00
end
%
% re estymacja A01
%
for c=2:2:C-1
    Tij_11s = diag((m(c)-1)*((alpha{c-1}*A{u(c-1)+1,u(c)+1})' .*(diag(A{u(c)+1,u(c)+1}^(m(c)-1)))).*beta{c});
    Sum_Tii_11s = sum_Tii_11s+Tii_11s;
end
%
% reestymacja A01
%
for c=1:2:C-1
    Tij_01s = (alpha{c}'*((A{u(c+1)+1,u(c+1)+1}^(m(c+1)-1)) *beta{c+1})').*A{u(c)+1,u(c+1)+1};
    sum_Tij_01s = sum_Tij_01s + Tij_01s; % suma elementów A01
end
%
% estymacja macierzy A10
%
for c=2:2:C-1
    Tij_10s = (alpha{c}'*((A{u(c+1)+1,u(c+1)+1}^(m(c+1)-1)) *beta{c+1})').*A{u(c)+1,u(c+1)+1};
    sum_Tij_10s = sum_Tij_10s + Tij_10s; % suma elementów A10
end
%
A_matrix = [sum_Tii_00s sum_Tij_01s; sum_Tij_10s sum_Tii_11s];
%
for i = 1:sum(partition)
    A_matrix(i,:) = A_matrix(i,:)/sum(A_matrix(i,:)); % normalizacja A
end
A{1}=A_matrix(1:partition(1),1:partition(1));
A{2}= A_matrix(partition(1)+1:partition(1)+partition(2),1+partition(1));
A{3}= A_matrix(1:partition(1),partition(1)+1:partition(1)+partition(2));
A{4}= A_matrix(partition(1)+1:partition(1)+partition(2),partition(1)+1:partition(1)+partition(2));
pi_est =[Gamma{1} Gamma{2}];
pi_est = pi_est/sum(pi_est);
pi_rec(iterations,:) = pi_est;
pi_u1 = pi_est(1:partition(1));
iterations
A_matrix
end
% koniec funkcji
